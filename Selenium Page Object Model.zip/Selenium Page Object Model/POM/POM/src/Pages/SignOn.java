package Pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;

import Lib.CommonFunctions;

public class SignOn {
	
	public  WebElement UserName,Password,SignIn,REGLink;
	public void SetSigninObjects() throws IOException{
		UserName = CommonFunctions.getObject("name", "userName");
		Password = CommonFunctions.getObject("name", "password");
		SignIn = CommonFunctions.getObject("name", "login");
	}


}
