package Pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;

import Lib.CommonFunctions;

public class FlightConfirmation {
	public  WebElement ConfirmMsg;

	public void SetFlightConfirmationObjects() throws IOException{	
		ConfirmMsg = CommonFunctions.getObject("xpath", "html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr[1]/td[2]/table/tbody/tr[5]/td/table/tbody/tr[1]/td/table/tbody/tr/td[1]/b/font/font/b/font[1]");
		//ConfirmMsg = CommonFunctions.getObject("xpath", "html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr[1]/td[2]/table/tbody/tr[5]/td/table/tbody/tr[1]/td/table/tbody/tr/td[1]/b/font/fo");
		}


}

