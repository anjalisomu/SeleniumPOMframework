package Pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;

import Lib.CommonFunctions;

public class Homepage {
	public  WebElement UserName,Password,SignIn,REGLink,SigninLink;

	public void SetHomepageObjects() throws IOException{	
		UserName = CommonFunctions.getObject("name", "userName");
		Password = CommonFunctions.getObject("name", "password");
		SignIn = CommonFunctions.getObject("name", "login");
		REGLink=CommonFunctions.getObject("linkText", "REGISTER");
		SigninLink = CommonFunctions.getObject("linkText", "SIGN-ON");
		
		}


}
