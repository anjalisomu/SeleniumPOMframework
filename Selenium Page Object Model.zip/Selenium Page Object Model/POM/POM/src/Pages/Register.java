package Pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;

import Lib.CommonFunctions;

public class Register {
	
	public  WebElement FirstName,LastName,Phone,Email,address,city,state,postalcode,country,UserName,Password,ConfirmPassword,btnSubmit;
	
public void SetRegisterObjects() throws IOException{	
	FirstName = CommonFunctions.getObject("name", "firstName");
	LastName = CommonFunctions.getObject("name", "lastName");
	Phone = CommonFunctions.getObject("name", "phone");
	Email = CommonFunctions.getObject("name", "userName");
	address = CommonFunctions.getObject("name", "address1");
	city = CommonFunctions.getObject("name", "city");
	state = CommonFunctions.getObject("name", "state");
	postalcode = CommonFunctions.getObject("name", "postalCode");
	country = CommonFunctions.getObject("name", "country");
	UserName = CommonFunctions.getObject("name", "email");
	Password = CommonFunctions.getObject("name", "password");
	ConfirmPassword = CommonFunctions.getObject("name", "confirmPassword");
	btnSubmit = CommonFunctions.getObject("name", "register");
	}
}
