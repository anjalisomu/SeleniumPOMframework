package Pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;

import Lib.CommonFunctions;

public class SelectFlight {
	public  WebElement OutFlight,InFlight,ReserveFlights;

	public void SetSelectFlightObjects() throws IOException{	
		OutFlight = CommonFunctions.getObject("name", "outFlight");
		InFlight = CommonFunctions.getObject("name", "inFlight");
		ReserveFlights = CommonFunctions.getObject("name", "reserveFlights");
		}


}
