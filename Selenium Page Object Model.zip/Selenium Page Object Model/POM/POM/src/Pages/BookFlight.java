package Pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;

import Lib.CommonFunctions;

public class BookFlight {
	public  WebElement FirsNm,LastNm,Cardnumber,BuyFlights;

	public void SetBookFlightObjects() throws IOException{	
		FirsNm = CommonFunctions.getObject("name", "passFirst0");
		LastNm = CommonFunctions.getObject("name", "passLast0");
		Cardnumber = CommonFunctions.getObject("name", "creditnumber");
		BuyFlights = CommonFunctions.getObject("name", "buyFlights");
		}



}
