package Pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;

import Lib.CommonFunctions;

public class FlightFinder {
	
	public  WebElement OneWay,Passengers,Fromport,FromMonth,FromDay,ToPort,ToMonth,ToDay,SerClass,Airline,FindFlights;
	
public void SetFlightFinderObjects() throws IOException{	
	OneWay = CommonFunctions.getObject("name", "tripType");
	Passengers=CommonFunctions.getObject("name", "passCount");
	Fromport = CommonFunctions.getObject("name", "fromPort");
	FromMonth = CommonFunctions.getObject("name", "fromMonth");
	FromDay=CommonFunctions.getObject("name", "fromDay");
	ToPort = CommonFunctions.getObject("name", "toPort");
	ToMonth = CommonFunctions.getObject("name", "toMonth");
	ToDay=CommonFunctions.getObject("name", "toDay");
	SerClass=CommonFunctions.getObject("name", "servClass");
	Airline=CommonFunctions.getObject("name", "airline");
	FindFlights=CommonFunctions.getObject("name", "findFlights");
	}
}
